﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour
{

	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		if(InputManager.Instance.GetClick() == InputManager.CLICK_STATE.ONECLICK)
			Scenemanager.Instance.LoadLevel("GameMain", 0.5f, 0.5f, 0.5f);
	}
}
