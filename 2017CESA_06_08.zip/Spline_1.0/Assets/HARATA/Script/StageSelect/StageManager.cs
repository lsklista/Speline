﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageManager : MonoBehaviour
{
	[SerializeField]	GameObject[] StageObj;
	Transform[] Trans;
	[SerializeField]	float fSpace;		// スプライトの間隔
	int nMinus;								// 要素数からこの数字を引いた数字以上の添え字の座標をマイナスする
	float[] StartPos;						// スタート地点

	bool bMoveTouch = false;				// タッチに追従フラグ
	public bool bInertia = false;					// 慣性移動中フラグ
	bool bMovesCloser = false;				// 近いところに移動中フラグ
	bool bButtonMove = false;				// ボタンを押されて、隣に移動フラグ
	
	float fMove;							// 移動量
	public float fInertia = 0;						// 慣性移動で使うスピード
	float fPreMove = 0;						// 前回の移動分
	[SerializeField, Range(0, 1)]	float fDeceleration;		// 減速の割合
	[SerializeField]	float fFinishInertia;					// 慣性移動終了の基準

	
	float fHeni;							// 変位
	float fTime = 0.0f;						// 移動が始まってからの時間
	[SerializeField]	float fMoveTime;	// 近いところに移動するのにかける時間
	float fStartSpeed;						// 初速度
	float fAccele;							// 加速度
	float[] fKijunPos = new float[6];		// 基準座標


	[SerializeField]	float fBottonMoveTime;	// ボタンを押された時に、何秒で隣に移動するか
	int nRightCnt = 0, nLeftCnt = 0;			// ボタン移動の連続で押されたカウンタ
	float fMoveDistance = 0;					// ボタン移動での進んだ距離
	float fPreMoveDistance = 0;					// 前回のボタン移動での進んだ距離
	float fTotalHeni = 0;						// ボタンが2回以上押された時用の、初期位置からの総変位量
	public float fBugResolution;						// バグ回避用(なぜか1回代入するとバグが解決したので)
	float fSearchNearDistance = 0;

	SpriteRenderer sr;	// デバッグ用

	// Use this for initialization
	void Start()
	{
		Trans = new Transform[StageObj.GetLength(0)];
		StartPos = new float[StageObj.GetLength(0)];

		// 座標をマイナスにする添え字計算
		nMinus = StageObj.GetLength(0);
		if(StageObj.GetLength(0) % 2 == 0)
			nMinus /= 2;
		else
			nMinus --;
		nMinus --;

		float fPos;
		for (int i = 0; i < StageObj.GetLength(0); i++)
		{
			Trans[i] = StageObj[i].GetComponent<Transform>();	// 子オブジェクトを取得

			// 初期位置セット
			fPos = fSpace * i;
			if(i >= StageObj.GetLength(0) - nMinus)
				fPos -= fSpace * StageObj.GetLength(0);

			StartPos[i] = fPos;
			Trans[i].localPosition = new Vector3(fPos, Trans[i].localPosition.y, Trans[i].localPosition.z);
		}
	}

	// Update is called once per frame
	void Update()
	{
		// 慣性移動
		Inertia();

		// 近いところに移動
		MovesCloser();

		// ボタンで隣に移動
		ButtonMove();

		// 移動
		Move();

		// ステージ選択
		StaSele();
	}


	// 慣性移動関係
	private void Inertia()
	{
		fMove = InputManager.Instance.GetDeltaPosition().x;

		// タッチに追従中に指を放したら、慣性移動開始
		if (Input.GetButtonUp("Fire1") && bMoveTouch)
		{
			fInertia = fMove;				// 移動量保存
			bMoveTouch = false;				// タッチ追従終了
			bInertia = true;				// 慣性移動開始
		}
		fInertia *= fDeceleration;			// 減速
		if (Mathf.Abs(fInertia) < fFinishInertia && bInertia)
		{
			fInertia = 0.0f;				// 停止
			bInertia = false;				// 慣性移動終了
			bMovesCloser = true;			// 近いところに移動開始

			// 真ん中に一番近いオブジェクトを探す
			float fDistance = 100;
			for (int i = 0; i < StageObj.GetLength(0); i++)
			{
				fKijunPos[i] = Trans[i].localPosition.x;	// 基準座標
				if (Mathf.Abs(fDistance) > Mathf.Abs(Trans[i].localPosition.x))
					fDistance = Trans[i].localPosition.x;
			}
			fStartSpeed = -fDistance * 2 / fMoveTime;		// 初速度の計算
			fAccele = -fStartSpeed / fMoveTime;		// 加速度の計算
			fTime = 0.0f;							// タイマーの初期化
		}
	}

	// 近いところに移動関係
	private void MovesCloser()
	{
		if(bMovesCloser)
		{
			fTime += Time.deltaTime;
			fHeni = (fStartSpeed * fTime) + (0.5f * fAccele * fTime * fTime);	// 変位の計算

			if (fTime >= fMoveTime)
			{
				bMovesCloser = false;

				// 一番近い基準座標に移動する
				MoveNear();

				fHeni = 0;
			}
		}
	}

	// 移動
	private void Move()
	{
		// クリックされた時に、場所がボタンだったらタッチに追従しない
		if (Input.GetButtonDown("Fire1") && !bMoveTouch)
		{
			Collider2D col = Physics2D.OverlapPoint(InputManager.Instance.GetCursolPosition());
			if(col)
			{
				if(col.tag != "StageSelect_Button")
				{
					bMoveTouch = true;
					bInertia = false;
					bMovesCloser = false;
					bButtonMove = false;

					// タッチされたので、カウンターのリセット
					nRightCnt = 0;
					nLeftCnt = 0;
					fMoveDistance = 0;
					fTotalHeni = 0;
					fHeni = 0;
				}
			}
			else
			{
				bMoveTouch = true;
				bInertia = false;
				bMovesCloser = false;
				bButtonMove = false;

				// タッチされたので、カウンターのリセット
				nRightCnt = 0;
				nLeftCnt = 0;
				fMoveDistance = 0;
				fTotalHeni = 0;
				fHeni = 0;
			}
		}

		for (int i = 0; i < StageObj.GetLength(0); i++)
		{
			if (bMoveTouch)
			{// タッチに追従
				Trans[i].localPosition = new Vector3(Trans[i].localPosition.x + fMove, Trans[i].localPosition.y, Trans[i].localPosition.z);
			}
			else if (bInertia)
			{// 慣性移動
				Trans[i].localPosition = new Vector3(Trans[i].localPosition.x + fInertia, Trans[i].localPosition.y, Trans[i].localPosition.z);
			}
			else if (bMovesCloser)
			{// 近いところに移動
				Trans[i].localPosition = new Vector3(fKijunPos[i] + fHeni, Trans[i].localPosition.y, Trans[i].localPosition.z);
			}
			else if(bButtonMove)
			{// ボタンを押されて隣に移動
				Trans[i].localPosition = new Vector3(fKijunPos[i] + fHeni, Trans[i].localPosition.y, Trans[i].localPosition.z);
			}

			// 左右ワープ
			if (Trans[i].localPosition.x > ((StageObj.GetLength(0) - nMinus - 1 + 0.5f) * fSpace))
			{
				Trans[i].localPosition = new Vector3(Trans[i].localPosition.x - (fSpace * StageObj.GetLength(0)), Trans[i].localPosition.y, Trans[i].localPosition.z);
				fKijunPos[i] -= fSpace * StageObj.GetLength(0);
			}
			else if (Trans[i].localPosition.x < ((-nMinus - 0.5f) * fSpace))
			{
				Trans[i].localPosition = new Vector3(Trans[i].localPosition.x + (fSpace * StageObj.GetLength(0)), Trans[i].localPosition.y, Trans[i].localPosition.z);
				fKijunPos[i] += fSpace * StageObj.GetLength(0);
			}
		}
	}

	// ステージ選択
	private void StaSele()
	{
		// 1クリック目で仮選択
		if (InputManager.Instance.GetClick() == InputManager.CLICK_STATE.ONECLICK)
		{
			Collider2D col = Physics2D.OverlapPoint(InputManager.Instance.GetCursolPosition());
			if (col && col.tag == "StageSelect_Stage")
			{
				// 目印で青に
				sr = col.GetComponent<SpriteRenderer>();
				sr.color = new Color(0, 0, 255);
			}
		}

		// 移動させたら選択解除
		if(InputManager.Instance.GetMove() && sr != null)
		{
			sr.color = new Color(255, 255, 255);
			sr = null;
		}

		// 指を話した時にsrがあれば選択
		if(Input.GetButtonUp("Fire1") && sr != null)
		{
			sr.color = new Color(255, 0, 0);
		}
	}

	// ボタンで隣に移動
	public void ButtonMoveSet(bool bLeft)
	{
		// 初速度の計算
		float fDistance;
		if(bLeft)
		{
			nLeftCnt++;
			fDistance = (fSpace * nLeftCnt) + fMoveDistance;
			if(nLeftCnt == 1)
			{
				fSearchNearDistance = SearchNearPos(false);				// 1タッチ目だったら距離を直す
				fDistance -= fSearchNearDistance;
			}
			fStartSpeed = -fDistance * 2 / fBottonMoveTime;
		}
		else
		{
			nRightCnt ++;
			fDistance = (fSpace * nRightCnt) - fMoveDistance;
			if (nRightCnt == 1)
			{
				fSearchNearDistance = SearchNearPos(true);				// 1タッチ目だったら距離を直す
				fDistance += fSearchNearDistance;
			}
			fStartSpeed = fDistance * 2 / fBottonMoveTime;
		}
		//Debug.Log("fSearchNearDistance : " + fSearchNearDistance);
		//Debug.Log("fStartSpeed : " + fStartSpeed);
		fAccele = -fStartSpeed / fBottonMoveTime;	// 加速度の計算
		fTime = 0.0f;								// タイマーの初期化
		fTotalHeni += fHeni;						// 今までの変位量を保存

		// 基準座標
		for (int i = 0; i < StageObj.GetLength(0); i++)
		{
			fKijunPos[i] = Trans[i].localPosition.x;
		}

		bMoveTouch = false;
		bInertia = false;
		bMovesCloser = false;
		bButtonMove = true;
	}

	// ボタンで隣に移動
	private void ButtonMove()
	{
		if(bButtonMove)
		{
			fTime += Time.deltaTime;
			if(fTime >= fBottonMoveTime)		// 時間補正(ぴったり移動してくれないので)
				fTime = fBottonMoveTime;

			fHeni = (fStartSpeed * fTime) + (0.5f * fAccele * fTime * fTime);	// 変位の計算
			fMoveDistance += fHeni - fPreMoveDistance;
			fPreMoveDistance = fMoveDistance;

			fBugResolution = fTotalHeni + fHeni;	// なぜか一度代入を挟むとバグが解決するっぽい

			if ((nRightCnt >= 1 && fBugResolution >= (nRightCnt * fSpace)) ||
				(nLeftCnt >= 1 && -fBugResolution >= (nLeftCnt * fSpace)))
			//if (((nRightCnt >= 1) && ((fTotalHeni + fHeni) >= (nRightCnt * fSpace))) ||
			//	(nLeftCnt >= 1 && -(fTotalHeni + fHeni) >= (nLeftCnt * fSpace)))
			{
				bButtonMove = false;

				// 止まったので、カウンターのリセット
				nRightCnt = 0;
				nLeftCnt = 0;
				fMoveDistance = 0;
				fTotalHeni = 0;
				fSearchNearDistance = 0;

				// 一番近い基準座標に移動する
				MoveNear();

				fHeni = 0;		// MoveNear()で使っているので、これだけ後で初期化
			}
		}
	}

	// 一番近い基準座標に移動する
	private void MoveNear()
	{
		int nNear = 0;				// 1番近い座標の添え字
		float fDistance = 100;		// 距離(適当に大きな数字)

		for (int i = 0; i < StageObj.GetLength(0); i++)
		{
			Trans[i].localPosition = new Vector3(fKijunPos[i] + fHeni, Trans[i].localPosition.y, Trans[i].localPosition.z);

			// ステージ1の位置を決めて、他はそこから1つづつずらす
			if (i == 0)
			{
				for (int j = 0; j < StartPos.GetLength(0); j++)
				{
					if (Mathf.Abs(fDistance) > Mathf.Abs(Trans[i].localPosition.x - StartPos[j]))
					{
						fDistance = Trans[i].localPosition.x - StartPos[j];
						nNear = j;
					}
				}
			}
			else
			{
				nNear++;
				if (nNear == 6)
					nNear -= 6;
			}

			Trans[i].localPosition = new Vector3(StartPos[nNear], Trans[i].localPosition.y, Trans[i].localPosition.z);
		}
	}

	// 一番近い座標までの距離を計算する
	// 引数 : プラス方向に探すか、マイナス方向に探すか
	private float SearchNearPos(bool bPlus)
	{
		float fDistance = 0;
		float fPos = 0;

		// -fSpace~fSpaceの範囲にある座標を探す。(右端にあるオブジェクトからプラス方向に探すのが大変なため、どっちでもいける真ん中を探す)
		for(int i = 0 ; i < StageObj.GetLength(0) ; i ++)
		{
			fPos = StageObj[i].transform.localPosition.x + fHeni;

			if (-fSpace < fPos && fPos < fSpace)
				break;
		}

		if(bPlus)
		{// プラス方向に探索
			fDistance = fSpace - fPos;
		}
		else
		{// マイナス方向に探索
			fDistance = -fSpace - fPos;
		}

		//Debug.Log("fPos : " + fPos);
		//Debug.Log("fDistance : " + fDistance);

		return fDistance;
	}
}
