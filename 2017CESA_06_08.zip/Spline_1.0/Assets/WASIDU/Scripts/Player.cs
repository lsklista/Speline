﻿//========================================================
// プレイヤーキャラ一体の動き
//========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    //--- メンバ変数
    // メンバ定数

    // メンバ変数
    [SerializeField] private GameObject m_Mahoujin;
    [SerializeField] private GameObject m_SummonObj;

    GameObject m_MagicSquareObject; // 魔方陣オブジェクト

    ParticleSystem m_UseFinissherParticle;  // 必殺技使用設定時のパーティクル

    //--- メンバ関数
	// Use this for initialization
    void Start()
    {
        m_UseFinissherParticle = GetComponent<ParticleSystem>();
        m_UseFinissherParticle.Pause();
    }

    //--- 必殺技使用設定
    public void UseFinisherAtack()
    {
        m_UseFinissherParticle.Play();
    }

    //--- 魔方陣設置
    public void SetMagicSquare()
    {
        Vector3 Pos = transform.position;
        Pos.y += 0.1f;
        m_MagicSquareObject = Instantiate(m_Mahoujin, Pos, Quaternion.identity) as GameObject;

        m_MagicSquareObject.transform.parent = m_SummonObj.transform;

    }

    //--- 召喚
    // 戻り値：出したオブジェクト
    public GameObject Summon()
    {
        GameObject SummonObj = m_MagicSquareObject.GetComponent<MagicSquare>().Summon();
        return SummonObj;
    }

    //--- 攻撃キャンセル
    public void AtackCancel()
    {
        m_UseFinissherParticle.Stop();
        Destroy(m_MagicSquareObject);
    }


    // 方向転換
    // 引数：向かせたいオブジェクト
    public void ChangeRot(GameObject ObjData)
    {
        transform.LookAt(ObjData.transform);
        m_MagicSquareObject.GetComponent<MagicSquare>().SetSummonsVec = transform.forward;

    }

}
