﻿//========================================================
// スコア管理
//========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;// 仮スコア・コンボ表示用

public class ScoreManager : MonoBehaviour
{
    //--- メンバ変数 ------------------------------------------------------------------------------------------------------------
    //--- メンバ定数

    //--- メンバ変数
    private int m_Score;    // スコア
    private int m_nComboCnt;   // コンボ数

    public Text m_ScoreText;  // 仮スコア表示
    public Text m_ComboText;  // 仮コンボ表示

    //--- メンバ関数 ------------------------------------------------------------------------------------------------------------
    ScoreManager()
    {
        m_Score = 0;
        m_nComboCnt = -1;

    }

    //--- コンボ設定
    public void SetCombo(bool bHit)
    {
        // 攻撃が消える時敵に当たっていたらコンボ加算

        if (bHit)
        {
            //--- コンボ加算
            m_nComboCnt++;


            m_ComboText.text = m_nComboCnt.ToString();
        }
        else
        {
            //--- コンボ初期値に
            m_nComboCnt = -1;

            m_ComboText.text = (m_nComboCnt + 1).ToString();
        }
    }

    //--- 得点加算
    public void AddScore(int AddScore)
    {
        m_Score += AddScore;

        m_ScoreText.text = m_Score.ToString();

        Debug.Log("得点加算");
    }

    public void ReSetScore()
    {
        m_Score = 0;
    }

    public int Score { get { return m_Score; } }
}
