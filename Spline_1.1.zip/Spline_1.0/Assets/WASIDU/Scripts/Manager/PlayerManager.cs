﻿//========================================================
// プレイヤーの制御(魔方陣制御に変更か)
//========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.SceneManagement;  // 現在のシーン取得用

using UnityEngine.UI;// 仮ストック表示

public class PlayerManager : MonoBehaviour
{
    // 攻撃ガイド線用クラス
    class AtackLineObjData
    {
        public GameObject AtackLine;    // 攻撃ガイド線オブジェクト
        public GameObject AtackObjA;    // 攻撃オブジェクトA
        public GameObject AtackObjB;    // 攻撃オブジェクトB
        public bool AddComboFlg;

        public AtackLineObjData(GameObject SetAtackLine, GameObject SetObjA, GameObject SetObjB)
        {
            AtackLine = SetAtackLine;
            AtackObjA = SetObjA;
            AtackObjB = SetObjB;

            LineRenderer AtackLineRenderer = SetAtackLine.GetComponent<LineRenderer>();
            AtackLineRenderer.SetPosition(0, AtackObjA.transform.position);
            AtackLineRenderer.SetPosition(1, AtackObjB.transform.position);

            AddComboFlg = false;
        }

    }

    //--- メンバ変数 ------------------------------------------------------------------------------------------------------------
    //--- メンバ定数
    private const float MOVE_TIME = 1.0f;  // 移動するまでの時間

    //--- メンバ変数
    [SerializeField] private GameObject m_AtackLinePrefub;  // 攻撃ガイド線プレハブ

    // 攻撃設定用
    private GameObject m_AttackSettingHitObj; // 攻撃設定用オブジェクト(タップした時のオブジェクト)
    #region 攻撃オブジェクトを配列で設定
    //private GameObject[]    m_AttackSettingObjArrey; // 攻撃設定用オブジェクト配列
    //private int m_AtackSetNowNumber;    // 現在設定する攻撃番号
    #endregion
    #region 攻撃オブジェクトを個別で設定
    private GameObject m_AttackSettingObjA; // 攻撃設定用オブジェクトA
    private GameObject m_AttackSettingObjB; // 攻撃設定用オブジェクトB
    private GameObject m_AttackSettingObjC; // 攻撃設定用オブジェクトC
    #endregion

    private bool m_NormalAtackFlg;

    // 必殺技用
    [SerializeField] private GameObject m_FinisherAtackObjPrefub;
    private bool    m_UseFinisher;      // 必殺技を使うかのフラグ
    private int     m_FinisherStock;    // 必殺技のストック

    private List<string> m_LinkPairDataList;    // 隣同士の情報
    private List<AtackLineObjData> m_PairObjDataList;

    [SerializeField] private GameObject m_EnemyParent;  // 敵の親オブジェクト
    [SerializeField] private ScoreManager m_ScoreManagerScript;  // 目標管理スクリプト

    //--- 消す予定のもの
    public Text m_FinisherStockNumText;  // 仮ストック表示

    //--- メンバ関数 ------------------------------------------------------------------------------------------------------------
    PlayerManager()
    {
        m_LinkPairDataList = new List<string>
        {
            {"A,B"},
            {"B,C"},
            {"C,D"},
            {"D,E"},
            {"E,F"},
            {"F,A"},
            {"B,A"},
            {"C,B"},
            {"D,C"},
            {"E,D"},
            {"F,E"},
            {"A,F"},
        };

        m_PairObjDataList = new List<AtackLineObjData>();

        // 攻撃設定用初期化
        #region 攻撃オブジェクトを配列で設定
        //m_AttackSettingObjArrey = new GameObject[3];
        //m_AtackSetNowNumber = 0;
        #endregion
        #region 攻撃オブジェクトを個別で設定
        m_AttackSettingObjA = null;
        m_AttackSettingObjB = null;
        m_AttackSettingObjC = null;
        #endregion

        m_NormalAtackFlg = false;

        m_UseFinisher   = false;
        m_FinisherStock = 0;
    }

    void Start()
    {
        FinisherAtack.EnemyParent = m_EnemyParent;

    }
	
	void Update ()
    {
        AtackSetting();

        //--- 攻撃ガイド線消滅判定
        for (int i = 0; i < m_PairObjDataList.Count; i++)
        {
            // 攻撃ガイド線に対応しているオブジェクトが存在するか判定
            if (m_PairObjDataList[i].AtackObjA != null &&
                m_PairObjDataList[i].AtackObjB != null)
            {
                SummonsBeast AtackScriptA = m_PairObjDataList[i].AtackObjA.GetComponent<SummonsBeast>();
                SummonsBeast AtackScriptB = m_PairObjDataList[i].AtackObjB.GetComponent<SummonsBeast>();

                m_PairObjDataList[i].AddComboFlg = AtackScriptA.EnemyHit & AtackScriptB.EnemyHit;
            }
            else
            {
                Destroy(m_PairObjDataList[i].AtackLine);

                //--- コンボ情報設定
                m_ScoreManagerScript.SetCombo(m_PairObjDataList[i].AddComboFlg);

                m_PairObjDataList.RemoveAt(i);
            }
        }

        #region デバッグコマンド
        //--- リセット
        if (Input.GetKeyDown(KeyCode.Space))
        {
        }
        //--- 必殺技ストック追加
        if (Input.GetKeyDown(KeyCode.F))
        {
            AddFinisherStock();
        }
        #endregion

    }

    //--- 攻撃設定
    private void AtackSetting()
    {
        switch(InputManager.Instance.GetClick())
        {
            case InputManager.CLICK_STATE.NONE:
                break;

            case InputManager.CLICK_STATE.ONECLICK:
                ClickRayCheck();
                //--- エフェクト出す(予定)
                break;

            case InputManager.CLICK_STATE.CLICK:

                //--- オブジェクトチェック
                if (m_AttackSettingHitObj == null)
                {
                    SEManager.Instance.Play("beep_fast");
                    AtackCansel();
                    return;
                }

                if (!m_UseFinisher)
                    SetNormalAtackObject();
                else
                    SetFinisherAtackObject();

                break;

            case InputManager.CLICK_STATE.DOUBLECLICK:

                // ストックがあるか
                if (m_FinisherStock < 1)
                    return;

                //--- オブジェクトチェック
                if (m_AttackSettingHitObj == null)
                {
                    SEManager.Instance.Play("beep_fast");
                    AtackCansel();
                    return;
                }

                Debug.Log("通常攻撃判定" + m_NormalAtackFlg);

                if (m_NormalAtackFlg)
                    return;

                Debug.Log("必殺技設定");

                m_UseFinisher = true;

                SetFinisherAtackObject();
                break;

        }

    }

    //--- クリック先オブジェクト取得
    // 戻り値:当たったオブジェクト(無かった場合null)
    GameObject ClickRayCheck()
    {
        RaycastHit hit;
        Ray ray;

        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        // タップ（クリック）した先にオブジェクトが無かった場合
        if (!Physics.Raycast(ray, out hit))
        {
            m_AttackSettingHitObj = null;
            return null;
        }

        m_AttackSettingHitObj = hit.transform.gameObject;

        return hit.transform.gameObject;
    }

    //--- 通常攻撃オブジェクト設定
    void SetNormalAtackObject()
    {
        // タップ（クリック）したオブジェクトがPlayerか判定
        if (m_AttackSettingHitObj.tag != "Player")
        {
            m_NormalAtackFlg = false;
            m_AttackSettingHitObj = null;
            return;
        }

        //--- 攻撃オブジェクト設定
        SetAtackObj();

        m_NormalAtackFlg = true;

        #region 攻撃オブジェクトを個別で設定
        //--- 攻撃オブジェクトが二つ設定されているか
        if ((m_AttackSettingObjA != null) &&
            (m_AttackSettingObjB != null))
        {
            // オブジェクトA,Bが隣同士か判定
            bool LinkPair = m_LinkPairDataList.Contains(m_AttackSettingObjA.name + "," + m_AttackSettingObjB.name);

            if (LinkPair)
            {// 隣同士か同じの場合、第一オブジェクト変更
                AtackObjectChange();
                return;
            }

            // ペアの場合、キャラの方向を変更、その後魔方陣出現
            Player PlayerScriptA = m_AttackSettingObjA.GetComponent<Player>();
            Player PlayerScriptB = m_AttackSettingObjB.GetComponent<Player>();
            PlayerScriptA.ChangeRot(m_AttackSettingObjB);
            PlayerScriptB.ChangeRot(m_AttackSettingObjA);

            // 召喚
            GameObject ObjA = PlayerScriptA.Summon();
            GameObject ObjB = PlayerScriptB.Summon();

            AtackLineObjData SetData = new AtackLineObjData(Instantiate(m_AtackLinePrefub), ObjA, ObjB);

            m_PairObjDataList.Add(SetData);

            m_AttackSettingObjA = null;
            m_AttackSettingObjB = null;
            m_NormalAtackFlg = false;
        }
        #endregion

        #region 攻撃オブジェクトを配列で設定
        ////--- 攻撃オブジェクトが二つ設定されているか
        //if (m_AtackSetNowNumber == 2)
        //{
        //    // オブジェクトA,Bが隣同士か判定
        //    bool Pair = m_LinkPairDataList.Contains(m_AttackSettingObjArrey[0].name + "," + m_AttackSettingObjArrey[1].name);

        //    if (Pair)
        //    {// 隣同士か同じの場合、第一オブジェクト変更
        //        AtackObjectChange();
        //        return;
        //    }

        //    // ペアの場合、キャラの方向を変更、その後魔方陣出現
        //    Player PlayerScriptA = m_AttackSettingObjArrey[0].GetComponent<Player>();
        //    Player PlayerScriptB = m_AttackSettingObjArrey[1].GetComponent<Player>();
        //    PlayerScriptA.ChangeRot(m_AttackSettingObjArrey[1]);
        //    PlayerScriptB.ChangeRot(m_AttackSettingObjArrey[0]);

        //    // 召喚
        //    GameObject ObjA = PlayerScriptA.Summon();
        //    GameObject ObjB = PlayerScriptB.Summon();

        //    AtackLineObjData SetData = new AtackLineObjData(Instantiate(m_AtackLinePrefub), ObjA, ObjB);

        //    m_PairObjDataList.Add(SetData);

        //    m_AtackSetNowNumber = 0;
        //}
        #endregion

    }

    //--- 必殺技オブジェクト設定
    void SetFinisherAtackObject()
    {
        // タップ（クリック）したオブジェクトがPlayerか判定
        if (m_AttackSettingHitObj.tag != "Player")
        {
            m_AttackSettingHitObj = null;
            return;
        }


        //--- 攻撃オブジェクト設定
        SetAtackObj();

        #region 攻撃オブジェクトを個別で設定
        //--- 攻撃オブジェクトが三つ設定されているか
        if ((m_AttackSettingObjA != null) &&
            (m_AttackSettingObjB != null) &&
            (m_AttackSettingObjC != null))
        {
            //--- 必殺技発動
            Player PlayerScriptA = m_AttackSettingObjA.GetComponent<Player>();
            Player PlayerScriptB = m_AttackSettingObjB.GetComponent<Player>();
            PlayerScriptA.AtackCancel();
            PlayerScriptB.AtackCancel();

            FinisheAtack();

            m_AttackSettingObjA = null;
            m_AttackSettingObjB = null;
            m_AttackSettingObjC = null;

            m_FinisherStock -= 1;
            m_FinisherStockNumText.text = m_FinisherStock.ToString();
        }
        #endregion

        #region 攻撃オブジェクトを配列で設定
        ////--- 攻撃オブジェクトが三つ設定されているか
        //if (m_AtackSetNowNumber >= 3)
        //{
        //    //--- 必殺技発動
        //    List<Player> PlayerScriptList = new List<Player>();
        //    m_AttackSettingObjArrey.ToList().ForEach(x => PlayerScriptList.Add(x.GetComponent<Player>()));

        //    PlayerScriptList.ForEach(x=>x.AtackCancel());

        //    FinisherAtack();

        //    m_AtackSetNowNumber = 0;
        //    m_FinisherStock -= 1;
        //    m_FinisherStockNumText.text = m_FinisherStock.ToString();
        //}
        #endregion
    }

    //--- 攻撃オブジェクト設定
    void SetAtackObj()
    {
        Player HitObjSqript = m_AttackSettingHitObj.GetComponent<Player>();

        #region 攻撃オブジェクトを個別で設定
        if (m_AttackSettingObjA == null)
        {//オブジェクトA指定
            m_AttackSettingObjA = m_AttackSettingHitObj;
            HitObjSqript.SetMagicSquare();

            if (m_UseFinisher)
                HitObjSqript.UseFinisherAtack();
        }
        else if (m_AttackSettingObjB == null)
        {//オブジェクトB指定

            // オブジェクトAと同じ場合
            if (m_AttackSettingObjA.name == m_AttackSettingHitObj.name)
                return;

            m_AttackSettingObjB = m_AttackSettingHitObj;
            HitObjSqript.SetMagicSquare();

            if (m_UseFinisher)
                HitObjSqript.UseFinisherAtack();
        }
        else if (m_AttackSettingObjC == null)
        {//オブジェクトC指定

            if (m_AttackSettingObjA.name == m_AttackSettingHitObj.name ||
                m_AttackSettingObjB.name == m_AttackSettingHitObj.name)
            {// 同じ場合
                return;
            }

            m_AttackSettingObjC = m_AttackSettingHitObj;
        }
        #endregion

        #region 攻撃オブジェクトを配列で設定

        ////--- 一体目と同じか判定
        //if (m_AtackSetNowNumber > 0 &&
        //    m_AttackSettingObjArrey[m_AtackSetNowNumber - 1].name == HitObj.name)
        //    return;

        //m_AttackSettingObjArrey[m_AtackSetNowNumber] = HitObj;
        //HitObjSqript.SetMagicSquare();

        //if (m_UseFinisher)
        //    HitObjSqript.UseFinisherAtack();

        //m_AtackSetNowNumber++;
        #endregion

        m_AttackSettingHitObj = null;
    }

    //--- 攻撃キャンセル
    void AtackCansel()
    {
        #region 攻撃オブジェクトを個別で設定
        if (m_AttackSettingObjA != null)
        {
            Player PlayerScriptA = m_AttackSettingObjA.GetComponent<Player>();
            PlayerScriptA.AtackCancel();
        }

        if (m_AttackSettingObjB != null)
        {
            Player PlayerScriptB = m_AttackSettingObjB.GetComponent<Player>();
            PlayerScriptB.AtackCancel();
        }

        m_AttackSettingObjA = null;
        m_AttackSettingObjB = null;
        #endregion

        m_UseFinisher = false;
        m_NormalAtackFlg = false;
        #region 攻撃オブジェクトを配列で設定
        //m_AtackSetNowNumber = 0;
        //List<Player> PlayerScriptList = new List<Player>();
        //m_AttackSettingObjArrey.ToList().ForEach(x => { if (x != null)PlayerScriptList.Add(x.GetComponent<Player>()); });
        //PlayerScriptList.ForEach(x => x.AtackCancel());
        #endregion
    }

    //--- 第一攻撃オブジェクト変更
    void AtackObjectChange()
    {
        #region 攻撃オブジェクトを個別で設定
        Player PlayerScriptA = m_AttackSettingObjA.GetComponent<Player>();
        Player PlayerScriptB = m_AttackSettingObjB.GetComponent<Player>();
        PlayerScriptA.AtackCancel();
        PlayerScriptB.AtackCancel();

        m_AttackSettingObjA = m_AttackSettingObjB;
        m_AttackSettingObjB = null;

        m_AttackSettingObjA.GetComponent<Player>().SetMagicSquare();
        #endregion

        #region 攻撃オブジェクトを配列で設定
        //m_AttackSettingObjArrey[0].GetComponent<Player>().AtackCancel();
        //m_AttackSettingObjArrey[0] = m_AttackSettingObjArrey[1];
        //m_AtackSetNowNumber--;
        #endregion
    }

    //--- 必殺技ストック加算
    public void AddFinisherStock()
    {
        m_FinisherStock++;
        m_FinisherStockNumText.text = m_FinisherStock.ToString();
    }

    //--- 必殺技処理
    private void FinisheAtack()
    {
        GameObject FinishObj = Instantiate(m_FinisherAtackObjPrefub, Vector3.zero, Quaternion.identity);
        FinisherAtack FinishSqript = FinishObj.GetComponent<FinisherAtack>();

        #region 攻撃オブジェクトを個別で設定
        //--- 三角形の頂点の位置
        Vector3 A = m_AttackSettingObjA.transform.position;
        Vector3 B = m_AttackSettingObjB.transform.position;
        Vector3 C = m_AttackSettingObjC.transform.position;

        FinishSqript.SetVertex(A, B, C);
        FinishSqript.CheckHit();
        #endregion

        #region 攻撃オブジェクトを配列で設定
        //List<Vector3> PosList = new List<Vector3>();
        //m_AttackSettingObjArrey.ToList().ForEach(x => PosList.Add(x.transform.position));
        //FinishSqript.SetVertex(PosList.ToArray());
        #endregion

        m_UseFinisher = false;
    }

}
