﻿//========================================================
// 目標管理
//========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TargetManager : MonoBehaviour
{
    //--- 目標情報データ
    class TargetData
    {
        float m_TimeLimit;    // 制限時間
        int m_TargetScore;    // 目標得点

        public TargetData(int SetTargetScore, float SetTimeLimit)
        {
            m_TimeLimit     = SetTimeLimit;
            m_TargetScore   = SetTargetScore;
        }

        public float TimeLimit { get { return m_TimeLimit;  } }
        public int TargetScore { get { return m_TargetScore; } }
    };

    //--- メンバ変数 ------------------------------------------------------------------------------------------------------------
    //--- メンバ定数

    //--- メンバ変数
    [SerializeField] private PlayerManager m_PlayerManager;
    private float   m_GameTime; // 時間

    private List<TargetData> m_TargetDataList; // 目標情報(ステージにより変更できるようにList)
    private int m_NowTargetNumber;  // 現在の目標

    [SerializeField] private ScoreManager m_ScoreManagerScript; // 現在のスコア取得用
    [SerializeField] private Image m_TimeImage; // 残り時間情報画像


    //--- メンバ関数 ------------------------------------------------------------------------------------------------------------
    TargetManager()
    {
        m_GameTime = 0.0f;

        m_NowTargetNumber = 0;

    }

    void Awake()
    {
        m_TargetDataList = new List<TargetData>();

        // 仮の値設定
        // ステージにより読み込みに変更予定
        m_TargetDataList.Add(new TargetData(200,10f));
        m_TargetDataList.Add(new TargetData(400,10f));
        m_TargetDataList.Add(new TargetData(500,10f));

    }
	
	// Update is called once per frame
	void Update ()
    {
        m_GameTime += Time.deltaTime;

        //--- クリアした時にシーン変更があるかと思うのでいらない(マージ後消す)
        if (m_NowTargetNumber >= m_TargetDataList.Count)
        {
            m_NowTargetNumber = m_TargetDataList.Count - 1;
        }

        //--- 制限時間表示
        m_TimeImage.fillAmount = 1 - m_GameTime / m_TargetDataList[m_NowTargetNumber].TimeLimit;

        //--- 一定時間ごとに判定（変更できるようにしておくか）
        if (m_GameTime > m_TargetDataList[m_NowTargetNumber].TimeLimit)
        {
            //--- 目標数達成しているか
            if (m_ScoreManagerScript.Score >= m_TargetDataList[m_NowTargetNumber].TargetScore)
            {// 達成している場合
                Debug.Log("目標" + (m_NowTargetNumber + 1) + "達成");
                m_NowTargetNumber++;    // 次の目標に

                if (m_NowTargetNumber % 2 == 0)
                    m_PlayerManager.AddFinisherStock();

            }
            else
            {// 失敗している場合

                //--- シーン変更に変える
                Debug.Log("失敗");
            }

            m_GameTime = 0.0f;
        }

        //--- 全ての目標を達成しているか
        if (m_NowTargetNumber >= m_TargetDataList.Count)
        {
            //--- シーン変更に変える
            Debug.Log("ゲームクリア");
        }
	}
}
