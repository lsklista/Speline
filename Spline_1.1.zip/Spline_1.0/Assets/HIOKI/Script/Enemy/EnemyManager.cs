﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyManager : MonoBehaviour {

	#region 他のスクリプト呼びよう
	[SerializeField]
	private GameObject _EnemyVe;
	private EnemyVerticalAdvance _EnemyVeObj;

	[SerializeField]
	private GameObject _EnemyB;
	private EnemyBase _EnemyBase;

	[SerializeField]
	private GameObject _EnemySi;
	private EnemySideAdvance _EnemySiObj;

	[SerializeField]
	private GameObject _EnemySq;
	private EnemySquareRotation _EnemySqObj;

	[SerializeField]
	private GameObject _EnemyVS;
	private EnemyVS _EnemyVSObj;

    [SerializeField]
    private GameObject _EnemyTv;
    private EnemyTriangleVertical _EnemyTvObj;
	#endregion

	[SerializeField]
	private Vector3[] SpawPos;

	[SerializeField]
	private Vector3[] SpawPos_Sq;

	[SerializeField]
	private Vector3[] SpawPos_Tv;

	[SerializeField]
	private int EnemyMax;

	private int nNowEnemy = 0;

	private int nCnt = 0;

    [SerializeField]
    private ScoreManager m_ScoreManagerScript;  // 目標管理スクリプト

	enum EnemyMove
	{
		VerticalAdvance = 0,
		SideAdvance,
		SquareRotation,
		SqRot,
		TriangleVertical,

		MAX_ENEMYMOVE
	};

	public static List<GameObject> myList = new List<GameObject>();

	// Use this for initialization
	void Start () {
		#region 他のスクリプト設定
		_EnemyVeObj = _EnemyVe.GetComponent<EnemyVerticalAdvance> ();
		_EnemyBase = _EnemyB.GetComponent<EnemyBase> ();
		_EnemySiObj = _EnemySi.GetComponent<EnemySideAdvance>();
		_EnemySqObj = _EnemySq.GetComponent<EnemySquareRotation>();
		_EnemyTvObj = _EnemyTv.GetComponent<EnemyTriangleVertical>();
		_EnemyVSObj = _EnemyVS.GetComponent<EnemyVS>();
		#endregion
	}
	
	// Update is called once per frame
	void Update () {
		Create ();
	}

	private void Create()
	{
		nCnt++;

		if (nCnt >= 10) {

			if (nNowEnemy >= EnemyMax)
				return;

			int nSpawPoint = Random.Range (0, SpawPos.Length);
			int nSpawPointSq = Random.Range (0, SpawPos_Sq.Length);
			//int nS = Random.Range (0,2);
			//int t;
			//if (nS == 0)
			//	t = 2;
			//else
			//	t = 3;
            int nMoveEnemies = 0;///*Random.Range (2, 4)t*/4;

			int nNowNomber;
			Vector3 vecSpaw = SpawPos[nSpawPoint];

			Debug.Log (nMoveEnemies);

			switch (nMoveEnemies) {
			case (int)EnemyMove.VerticalAdvance:			//縦移動
				GameObject EnemyVertical = Instantiate(_EnemyVeObj.CreateEnemyVertical(),vecSpaw,_EnemyVeObj.RotVertical(Random.Range(0,2)));	//生成
				myList.Add (EnemyVertical);													//追加
				nNowNomber = myList.Count;												//セット
				EnemyVertical.GetComponent<EnemyBase>().SetNomber = nNowEnemy;				//番号セット
				EnemyVertical.GetComponent<EnemyBase>().TargetManager = m_ScoreManagerScript;				//番号セット
                EnemyVertical.transform.SetParent(this.gameObject.transform);
				break;
			case (int)EnemyMove.SideAdvance:				//横移動
				GameObject EnemySide = Instantiate(_EnemySiObj.CreateEnemySide(),vecSpaw,_EnemySiObj.RotSide(Random.Range(0,2)));	//生成
				myList.Add (EnemySide);													//追加
				nNowNomber = myList.Count;												//セット
				EnemySide.GetComponent<EnemyBase>().SetNomber = nNowEnemy;				//番号セット
                EnemySide.transform.SetParent(this.gameObject.transform);
				break;
			case (int)EnemyMove.SquareRotation:				//四角回転移動
				GameObject EnemySquare = Instantiate(_EnemySqObj.CreateEnemySquare(),SpawPos[1],_EnemySqObj.RotSquare(Random.Range(0,4)));	//生成
				myList.Add (EnemySquare);													//追加
				nNowNomber = myList.Count;												//セット
				EnemySquare.GetComponent<EnemyBase>().SetNomber = nNowEnemy;				//番号セット
                EnemySquare.transform.SetParent(this.gameObject.transform);
				break;
			case (int)EnemyMove.SqRot:
				Debug.Log ("Aaa");
				GameObject EnemySV = Instantiate(_EnemyVSObj.CreateEnemyVS(), SpawPos_Sq[nSpawPointSq],_EnemyVSObj.VSRot(nSpawPointSq));	//生成
				myList.Add (EnemySV);													//追加
				nNowNomber = myList.Count;												//セット
				EnemySV.GetComponent<EnemyBase>().SetNomber = nNowEnemy;				//番号セット
                EnemySV.transform.SetParent(this.gameObject.transform);
				break;
            case (int)EnemyMove.TriangleVertical:
                GameObject EnemyTriangleV = Instantiate(_EnemyTvObj.CreateEnemyTriangleVertical(), SpawPos[1], _EnemyTvObj.RotTriangleVertical(Random.Range(0, 4)));
                myList.Add(EnemyTriangleV);													//追加
                nNowNomber = myList.Count;												//セット
                EnemyTriangleV.GetComponent<EnemyBase>().SetNomber = nNowEnemy;				//番号セット
                EnemyTriangleV.transform.SetParent(this.gameObject.transform);
                break;
			}

			nNowEnemy++;
			nCnt = 0;
		}
	}

	public void DostroyEnemy(int nNom)
	{
		myList.RemoveAt (nNom);
	}
    
    #region デバッグコマンド
	public void SpownReset()
    {
        nNowEnemy = 0;
	}
    
    #endregion
}
