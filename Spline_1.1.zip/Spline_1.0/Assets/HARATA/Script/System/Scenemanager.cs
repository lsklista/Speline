﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scenemanager : MonoBehaviour
{
	private static Scenemanager instance;

	private bool isFading = false;  // フェード中かどうか


	public static Scenemanager Instance
	{
		get
		{
			if (instance == null)
			{
				instance = (Scenemanager)FindObjectOfType(typeof(Scenemanager));

				if (instance == null)
				{
					GameObject go = new GameObject("Scenemanager");
					instance = go.AddComponent<Scenemanager>();
				}
			}

			return instance;
		}
	}

	public void Awake()
	{
		if (this != Instance)
		{
			Destroy(this);
			return;
		}

		DontDestroyOnLoad(this.gameObject);
	}

	// 描画遷移
	public void LoadLevel(string scene, float fadeinTime, float waitTime, float fadeoutTime)
	{
		if (this.isFading)
			return;

		float time = 0;

		Fade.Instance.FadeIn(fadeinTime, () =>
		{
			// シーン切り替え
			SceneManager.LoadScene(scene);

			Fade.Instance.FadeOut(fadeoutTime, () =>
			{

			});
		});
	}

	// フェードしているか
	public bool GetisFading()
	{
		return isFading;
	}
}
