﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageSelect_Button : MonoBehaviour {

	StageManager SM;

	// Use this for initialization
	void Start ()
	{
		SM = GameObject.Find("StageManager").GetComponent<StageManager>();
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}

	public void OnTapLeftButton()
	{
		SM.ButtonMoveSet(true);
	}

	public void OnTapRightButton()
	{
		SM.ButtonMoveSet(false);
	}
}
